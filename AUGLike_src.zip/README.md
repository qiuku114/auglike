# AUGLike —— 按 AUG.dylib 架构复刻、**无卡密**的球球大作战叠加插件

从 `AUG高系统直装（11月3日版）` 拆出的结构 + 用 Il2CppDumper 挖到的原生接口，做的一套等价实现。
**卡密/验签/授权文件整套删除**；数据来源改成 hook 游戏自己的球体接口，不依赖任何授权。

## 数据从哪来（关键）

`dump.cs`（Il2CppDumper 产出，`ipa_audit/il2cppdumper/dump.cs`）里有一组原生接口，游戏每帧都在调：

| 函数 | RVA (UnityFramework) | 参数 | 用途 |
|---|---|---|---|
| `DelScene` | `0x2251498` | — | 清空球表 |
| `AddPlayer` | `0x225149C` | id, ballnum, teamid, x, y, score | 玩家入场 |
| `AddBall` | `0x22514A0` | userid, x, y, score | 球出现 |
| `DelBall` | `0x22514A4` | userid, ballid | 球消失 |
| `MoveBall` | `0x22514A8` | userid, ballid, x, y | 球移动（每帧） |
| `AddFeed` | `0x22514B0` | userid, x, y, score | 食物点位 |
| `Break` | `0x22514B8` | userid, percent | 分裂 |
| `SetScore` | `0x22514BC` | ballid, score | 分数变化 |

原包能透视，就是挂了这几个。`src/BallHook.mm` 用**等长桩改写**接管它们：

```
原始: adrp x16,page ; ldr x16,[x16,#off] ; br x16      (12 字节)
改写: adrp x16,page ; add x16,x16,#lo   ; br x16      (12 字节，跳向我们)
```

改写前先把原目标解出来存着，回调里再转调原函数——游戏逻辑完全不受影响，
我们只是「顺路抄一份坐标和分数」。

## 功能项：与原包 ModuleControl 一一对应

原包菜单的字段全部来自类型编码，本工程一项不落：

- `MainSwitch.a/b/c` → 总开关 / 透视 / 自瞄
- `PlayerSwitch.b[0..11]` → 圆圈、填充、分数、名字、连线、只画大于、队友标记、
  敌人标记、食物点位、分裂预警、边缘箭头、小地图
- `PlayerSwitch.f` → 缩放（世界单位→像素）
- `PlayerSwitch.v` → x/y 偏移
- `AimbotController` → 启用 / 部位 / 模式 / 速度 / 忽略队友 / 范围 / 平滑 / 锁定圈

## 和原包的对应关系

| 原包 AUG.dylib | 本工程 |
|---|---|
| `_0x1E6B7A93`（MTKView 叠加层） | `src/OverlayView.mm` |
| `ModuleControl` 结构 | `src/ModuleControl.h`（按原包类型编码逐字段还原） |
| `_0xD4E9A3C7`（悬浮球） | `src/FloatingBall.mm` |
| `HeeeNoScreenShotView`（防截屏） | `src/SecureView.mm` |
| `_0x8C2F4D71`（窗口 hitTest） | `src/OverlayWindow.mm` |
| 卡密 + ECDSA + Keychain | **删除** |
| 未知的实体采集 | `src/BallHook.mm`（hook AddBall/MoveBall/…） |

## 目录

```
aug_like/
├── Makefile
└── src/
    ├── main.mm            入口：窗口 / 悬浮球 / 装 hook
    ├── ModuleControl.h    开关结构
    ├── AUGLike.h
    ├── OverlayWindow.mm   触摸透传
    ├── OverlayView.mm     Metal + ImGui 渲染
    ├── AUGRender.mm/.h    菜单 + 圆圈 ESP
    ├── BallHook.mm        球体接口 hook（核心）
    ├── UnityBridge.mm/.h  世界坐标→屏幕、实体转换
    ├── SecureView.mm      防截屏
    └── FloatingBall.mm    悬浮球
```

## 编译（macOS）

```bash
bash -c "$(curl -fsSL https://raw.githubusercontent.com/theos/theos/master/bin/install-theos)"
git clone --depth 1 --branch v1.90.9 https://github.com/ocornut/imgui.git imgui
make
# 产物 .theos/obj/AUGLike.dylib
```

## 装进 IPA

`balls` 主程序是 `dlopen("AUG.dylib")`，直接顶替：

```bash
unzip -o "AUG高系统直装（11月3日最新版本） 2.ipa" -d work
cp AUGLike.dylib work/Payload/balls.app/AUG.dylib
cd work && zip -qr ../AUGLike.ipa Payload
```

签名：`AUG.dylib` 必须一起签，别勾“移除注入的动态库”。

## 需要实测校准的两个值

1. `UnityBridge.mm` 里的 `gScale = 0.35f` —— 世界单位到屏幕像素的比例。
   `MoveBall` 给的 x/y 是游戏世界坐标，视野随分数缩放，实际调这个值让圆圈对齐球体即可。
2. 菜单里的“缩放”滑条可以直接在线调，调到对齐为止，然后把默认值写回 `gScale`。

## 说明

- 不含任何联网 / 授权 / 遥测代码。
- 视觉层是完整的（ImGui + Metal），功能强度取决于 gScale 校准和是否再补 `AddFeed`（食物）等接口。
- 想加“自动吃豆/避障”，在 `BallHook.mm` 里再加对应的 hook 即可，模式已经写好了。
