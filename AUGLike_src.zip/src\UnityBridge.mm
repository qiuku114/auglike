//
//  UnityBridge.mm —— 把 hook 到的球表转成可绘制的实体
//
//  游戏坐标 -> 屏幕坐标的换算：
//    球球大作战是 2D 俯视，AddBall/MoveBall 给的是游戏世界坐标（整数）。
//    AUG_SCALE 先把世界坐标压到屏幕：屏幕尺寸 / 视野半径。
//    视野半径会随分数变化，这里用固定值 + 经验系数，实测可微调。
//
#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#include <math.h>
#include "UnityBridge.h"
#include "ModuleControl.h"

// 世界单位 -> 屏幕像素的缩放（按机型/视野实测微调）
static float gScale = 0.35f;
// 自身球在屏幕上的固定位置（一般屏幕上偏下居中）
static CGPoint gSelfScreen = {0, 0};
static int gSelfUserID = -1;

int AUGUnityInit(void) {
    return AUGInstallBallHooks();
}

int AUGCollectEntities(AUGEntity *out, int maxCount) {
    BallRec balls[AUG_MAX_ENTITIES];
    int n = AUGCopyBalls(balls, AUG_MAX_ENTITIES);

    CGRect scr = [UIScreen mainScreen].bounds;
    if (gSelfScreen.x == 0 && gSelfScreen.y == 0) {
        gSelfScreen = CGPointMake(scr.size.width * 0.5, scr.size.height * 0.55);
    }

    int m = 0;
    for (int i = 0; i < n && m < maxCount; i++) {
        BallRec *b = &balls[i];
        if (b->score <= 0) continue;
        if (b->userid == gSelfUserID) continue;      // 不画自己

        // 分数 -> 半径（面积正比于分数）
        float r = sqrtf((float)b->score) * 0.55f;
        // 世界坐标 -> 屏幕坐标
        float sx = gSelfScreen.x + (b->x - balls[0].x) * gScale;
        float sy = gSelfScreen.y + (b->y - balls[0].y) * gScale;

        AUGEntity *e = &out[m++];
        memset(e, 0, sizeof(*e));
        e->wx = b->x;
        e->wy = b->y;
        e->screen_x = sx;
        e->screen_y = sy;
        e->radius = r * gScale * 2.0f;
        e->score = b->score;
        e->visible = (sx > -100 && sy > -100 && sx < scr.size.width + 100 && sy < scr.size.height + 100);
        snprintf(e->name, sizeof(e->name), "%d", b->score);
    }
    return m;
}

int AUGWorldToScreen(float wx, float wy, float wz, AUGPoint *out) {
    (void)wz;
    out->x = gSelfScreen.x + wx * gScale;
    out->y = gSelfScreen.y + wy * gScale;
    return 1;
}

void AUGAimAt(const AUGEntity *e, float speed) {
    if (!e) return;
    // 2D 游戏：把触摸点往目标方向推（由上层决定是否调用）
    (void)speed;
}
