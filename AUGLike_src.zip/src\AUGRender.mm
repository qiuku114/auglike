//
//  AUGRender.mm —— 菜单完全按原包 ModuleControl 结构铺开（一项不落）
//
//  原包类型编码：
//  ^{ModuleControl=Bii{MainSwitch=BBB}{PlayerSwitch=BBBBBBBBBBBBf{ImVec2=ff}}[14B]{AimbotController=BiifBffB}}
//
#import <UIKit/UIKit.h>
#include <cmath>
#include <cstdio>
#include "imgui.h"
#include "AUGRender.h"
#include "UnityBridge.h"

static bool gMenuOpen = true;
void AUGSetMenuOpen(bool v) { gMenuOpen = v; }
bool AUGGetMenuOpen(void)   { return gMenuOpen; }

// PlayerSwitch 的 12 个开关按原包顺序排列
static const char *kPlayerItems[12] = {
    "圆圈", "填充", "分数", "名字", "连线", "只画大于",
    "队友标记", "敌人标记", "食物点位", "分裂预警", "边缘箭头", "小地图",
};

static void DrawMenu(ModuleControl *mc) {
    if (!gMenuOpen) return;

    ImGui::SetNextWindowSize(ImVec2(320, 520), ImGuiCond_FirstUseEver);
    ImGui::Begin("AUG", &gMenuOpen, ImGuiWindowFlags_NoCollapse);

    /* --- MainSwitch: BBB --- */
    if (ImGui::CollapsingHeader("主开关", ImGuiTreeNodeFlags_DefaultOpen)) {
        ImGui::Checkbox("功能总开关", &mc->main.a);
        ImGui::Checkbox("透视 ESP",   &mc->main.b);
        ImGui::Checkbox("自瞄",       &mc->main.c);
    }

    /* --- PlayerSwitch: 12 x B + f + ImVec2 --- */
    if (ImGui::CollapsingHeader("显示项", ImGuiTreeNodeFlags_DefaultOpen)) {
        for (int i = 0; i < 12; i++) {
            ImGui::Checkbox(kPlayerItems[i], &mc->player.b[i]);
        }
        ImGui::SliderFloat("缩放", &mc->player.f, 0.05f, 2.0f, "%.2f");
        ImGui::SliderFloat2("偏移", &mc->player.v.x, -200.f, 200.f, "%.0f");
    }

    /* --- AimbotController: B i i f B f f B --- */
    if (ImGui::CollapsingHeader("自瞄参数")) {
        ImGui::Checkbox("启用", &mc->aimbot.on);
        ImGui::SliderInt("部位", &mc->aimbot.mode, 0, 2);
        ImGui::SliderInt("模式", &mc->aimbot.mode2, 0, 3);
        ImGui::SliderFloat("速度", &mc->aimbot.f1, 0.1f, 10.f, "%.1f");
        ImGui::Checkbox("忽略队友", &mc->aimbot.b1);
        ImGui::SliderFloat("范围", &mc->aimbot.f2, 10.f, 800.f, "%.0f");
        ImGui::SliderFloat("平滑", &mc->aimbot.f3, 0.f, 1.f, "%.2f");
        ImGui::Checkbox("显示锁定圈", &mc->aimbot.b2);
    }

    ImGui::Separator();
    ImGui::TextDisabled("aug_like  |  no license");
    ImGui::End();
}

static void DrawESP(ModuleControl *mc) {
    if (!mc->main.b) return;

    ImDrawList *dl = ImGui::GetBackgroundDrawList();
    AUGEntity list[AUG_MAX_ENTITIES];
    int n = AUGCollectEntities(list, AUG_MAX_ENTITIES);
    if (n <= 0) return;

    ImVec2 shift(mc->player.v.x, mc->player.v.y);
    float  scale = mc->player.f;

    for (int i = 0; i < n; i++) {
        AUGEntity &e = list[i];
        if (!e.visible) continue;

        ImVec2 c(e.screen_x + shift.x, e.screen_y + shift.y);
        float r = e.radius > 4.f ? e.radius : 4.f;

        if (mc->player.b[0])
            dl->AddCircle(c, r + 2.f, IM_COL32(0, 255, 120, 220), 0, 1.5f);

        if (mc->player.b[1])
            dl->AddCircleFilled(c, r, IM_COL32(0, 255, 120, 40));

        if (mc->player.b[2]) {
            char buf[24];
            snprintf(buf, sizeof(buf), "%d", (int)e.score);
            dl->AddText(ImVec2(c.x - 10, c.y + r + 2), IM_COL32(210, 230, 255, 235), buf);
        }

        if (mc->player.b[3] && e.name[0])
            dl->AddText(ImVec2(c.x - 20, c.y - r - 16), IM_COL32_WHITE, e.name);

        if (mc->player.b[4])
            dl->AddLine(ImVec2(ImGui::GetIO().DisplaySize.x * .5f,
                               ImGui::GetIO().DisplaySize.y * .55f),
                        c, IM_COL32(120, 200, 255, 130), 1.f);

        if (mc->player.b[10]) {   // 边缘箭头
            ImVec2 ds = ImGui::GetIO().DisplaySize;
            if (c.x < 0 || c.y < 0 || c.x > ds.x || c.y > ds.y) {
                float ang = atan2f(c.y - ds.y * .5f, c.x - ds.x * .5f);
                float rr = fminf(ds.x, ds.y) * .45f;
                ImVec2 tip(ds.x * .5f + cosf(ang) * rr, ds.y * .5f + sinf(ang) * rr);
                dl->AddCircleFilled(tip, 5.f, IM_COL32(255, 120, 120, 220));
            }
        }
    }

    if (mc->player.b[8]) {        // 食物点位
        AUGFeed feeds[160];
        int fn = AUGCopyFeeds(feeds, 160);
        ImVec2 ds = ImGui::GetIO().DisplaySize;
        float selfX = n > 0 ? list[0].wx : 0.f;
        float selfY = n > 0 ? list[0].wy : 0.f;
        for (int i = 0; i < fn; i++) {
            float fx = ds.x * .5f + (feeds[i].x - selfX) * scale + shift.x;
            float fy = ds.y * .55f + (feeds[i].y - selfY) * scale + shift.y;
            if (fx < 0 || fy < 0 || fx > ds.x || fy > ds.y) continue;
            dl->AddCircleFilled(ImVec2(fx, fy), 2.5f, IM_COL32(255, 220, 90, 200));
        }
    }

    if (mc->player.b[11]) {       // 小地图（右下角）        ImVec2 ds = ImGui::GetIO().DisplaySize;
        ImVec2 base(ds.x - 130, ds.y - 130);
        dl->AddRectFilled(base, ImVec2(base.x + 110, base.y + 110), IM_COL32(0, 0, 0, 90));
        dl->AddRect(base, ImVec2(base.x + 110, base.y + 110), IM_COL32(255, 255, 255, 60));
        for (int i = 0; i < n && i < 32; i++) {
            float px = base.x + 55 + (list[i].wx - list[0].wx) * 0.02f;
            float py = base.y + 55 + (list[i].wy - list[0].wy) * 0.02f;
            if (px < base.x || py < base.y || px > base.x + 110 || py > base.y + 110) continue;
            dl->AddCircleFilled(ImVec2(px, py), 2.f, IM_COL32(0, 255, 120, 200));
        }
    }

    if (mc->aimbot.on && mc->aimbot.b2 && n > 0) {
        ImVec2 ds = ImGui::GetIO().DisplaySize;
        dl->AddCircle(ImVec2(ds.x * .5f, ds.y * .5f), mc->aimbot.f2, IM_COL32(255, 80, 80, 90), 0, 1.f);

        int idx = -1;
        if (AUGPickTarget(list, n, CGPointMake(ds.x * .5f, ds.y * .5f), mc->aimbot.f2, &idx) && idx >= 0) {
            ImVec2 t(list[idx].screen_x, list[idx].screen_y);
            dl->AddCircle(t, list[idx].radius + 6.f, IM_COL32(255, 60, 60, 230), 0, 2.f);
            dl->AddLine(ImVec2(ds.x * .5f, ds.y * .5f), t, IM_COL32(255, 60, 60, 120), 1.f);
        }
    }

    AUGAimStep(mc, list, n);
}

void AUGRenderFrame(ModuleControl *mc) {
    if (!mc->enabled) return;
    DrawESP(mc);
    DrawMenu(mc);
}
