//
//  SecureView.mm —— 防截屏容器（对应原包 HeeeNoScreenShotView）
//
//  原理：把一个 secureTextEntry 的 UITextField 铺在视图层级里，
//  iOS 的截屏/录屏 API 会把这个图层渲染成空白。
//
#import "AUGLike.h"

@implementation AUGSecureView

- (instancetype)initWithFrame:(CGRect)frame {
    if ((self = [super initWithFrame:frame])) {
        _decoyField = [[UITextField alloc] initWithFrame:self.bounds];
        _decoyField.secureTextEntry = YES;
        _decoyField.userInteractionEnabled = NO;
        _decoyField.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleHeight;
        [self addSubview:_decoyField];
    }
    return self;
}

// 让子视图照常显示，但截屏时整层为空白
- (void)layoutSubviews {
    [super layoutSubviews];
    _decoyField.frame = self.bounds;
    [self bringSubviewToFront:_decoyField];
}

- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event {
    UIView *v = [super hitTest:point withEvent:event];
    return (v == _decoyField) ? self : v;
}

@end
